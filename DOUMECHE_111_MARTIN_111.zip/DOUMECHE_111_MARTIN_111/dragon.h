/**
 * @file dragon.h
 * @brief D�finition structure Dragon
 * Projet SDA 1
 */
#pragma once
#include "position.h"

typedef struct {
	Position pos;
} Dragon;