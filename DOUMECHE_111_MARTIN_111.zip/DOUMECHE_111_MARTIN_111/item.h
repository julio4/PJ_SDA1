/**
 * @file Item.h
 * @brief Caract�risation Item en Case
 * Projet SDA 1
 */
#pragma once

#include "case.h"

typedef Case Item;