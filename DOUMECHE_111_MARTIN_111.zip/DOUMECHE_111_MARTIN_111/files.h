/**
 * @file files.h
 * @brief Configuration fichier en entr�e
 * Projet SDA 1
 */
#pragma once

enum { STRING_SIZE = 30 };

const char fichier[STRING_SIZE] = "in.txt";