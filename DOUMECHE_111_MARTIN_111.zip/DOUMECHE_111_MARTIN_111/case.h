/**
 * @file case.h
 * @brief D�finition structure Case
 * Projet SDA 1
 */
#pragma once

typedef struct {
	char car;
	bool estLu = false;
} Case;