/**
 * @file position.h
 * @brief D�finition structure Position
 * Projet SDA 1
 */
#pragma once

typedef struct {
	unsigned int z, y, x;
} Position;
